import io
import datetime as _dt

from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    send_file,
)
from flask_login import login_required

import pandas as pd

from app import db
from app.models import User, OvertimeEntry, Approver, Product, Activity
from app.utils import parse_date, parse_time, compute_total_hours, admin_required

admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/dashboard")
@login_required
@admin_required

def dashboard():
    users = User.query.order_by(User.full_name.asc()).all()
    products = Product.query.order_by(Product.name.asc()).all()
    activities = Activity.query.order_by(Activity.name.asc()).all()

    user_id = request.args.get("user_id", type=int)
    product_id = request.args.get("product_id", type=int)
    activity_id = request.args.get("activity_id", type=int)
    entry_type = request.args.get("entry_type", "")
    date_from_str = request.args.get("date_from", "")
    date_to_str = request.args.get("date_to", "")

    date_from = parse_date(date_from_str)
    date_to = parse_date(date_to_str)

    base_query = OvertimeEntry.query.join(User)

    if user_id:
        base_query = base_query.filter(OvertimeEntry.user_id == user_id)
        selected_user = db.session.get(User, user_id)
    else:
        selected_user = None

    if product_id:
        base_query = base_query.filter(OvertimeEntry.product_id == product_id)
    if activity_id:
        base_query = base_query.filter(OvertimeEntry.activity_id == activity_id)
    if entry_type:
        base_query = base_query.filter(OvertimeEntry.entry_type == entry_type)

    if date_from:
        base_query = base_query.filter(OvertimeEntry.date >= date_from)
    if date_to:
        base_query = base_query.filter(OvertimeEntry.date <= date_to)

    entries = (
        base_query.filter(OvertimeEntry.is_deleted == False)
        .order_by(OvertimeEntry.date.desc(), OvertimeEntry.start_time.desc())
        .all()
    )
    deleted_entries = (
        base_query.filter(OvertimeEntry.is_deleted == True)
        .order_by(OvertimeEntry.date.desc(), OvertimeEntry.start_time.desc())
        .all()
    )

    total_extra = sum(e.total_hours for e in entries if e.entry_type == "Horas Extras") if entries else 0.0
    total_comp = sum(e.total_hours for e in entries if e.entry_type == "Compensación") if entries else 0.0

    stats = {}
    for e in entries:
        if e.user_id not in stats:
            stats[e.user_id] = {"user": e.user, "extra": 0.0, "comp": 0.0}
        if e.entry_type == "Horas Extras":
            stats[e.user_id]["extra"] += e.total_hours
        elif e.entry_type == "Compensación":
            stats[e.user_id]["comp"] += e.total_hours

    chart_labels = [s["user"].full_name for s in stats.values()]
    chart_extra = [round(s["extra"], 2) for s in stats.values()]
    chart_comp = [round(s["comp"], 2) for s in stats.values()]
    chart_net = [round(s["extra"] - s["comp"], 2) for s in stats.values()]

    return render_template(
        "admin_dashboard.html",
        title="Dashboard Admin",
        users=users,
        products=products,
        activities=activities,
        entries=entries,
        deleted_entries=deleted_entries,
        total_extra=total_extra,
        total_comp=total_comp,
        selected_user=selected_user,
        selected_product_id=product_id,
        selected_activity_id=activity_id,
        selected_entry_type=entry_type,
        date_from=date_from_str,
        date_to=date_to_str,
        chart_labels=chart_labels,
        chart_extra=chart_extra,
        chart_comp=chart_comp,
        chart_net=chart_net,
    )
# ---------------- Usuarios ----------------
@admin_bp.route("/users")
@login_required
@admin_required
def list_users():
    users = User.query.order_by(User.full_name.asc()).all()
    return render_template("users_list.html", title="Usuarios", users=users)


@admin_bp.route("/users/create", methods=["GET", "POST"])
@login_required
@admin_required
def create_user():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        role = request.form.get("role", "user")
        password = request.form.get("password", "")
        password2 = request.form.get("password2", "")

        if password != password2:
            flash("Las contraseñas no coinciden.", "error")
        elif User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Ya existe un usuario con ese nombre de usuario o correo.", "error")
        else:
            new_user = User(
                full_name=full_name,
                username=username,
                email=email,
                role=role,
            )
            new_user.set_password(password)
            db.session.add(new_user)
            db.session.commit()
            flash("Usuario creado correctamente.", "success")
            return redirect(url_for("admin.list_users"))

    return render_template("create_user.html", title="Crear usuario")


@admin_bp.route("/users/<int:user_id>/reset-password", methods=["GET", "POST"])
@login_required
@admin_required
def reset_password(user_id):
    user = db.session.get(User, user_id)
    if not user:
        return "Usuario no encontrado", 404

    if request.method == "POST":
        password = request.form.get("password", "")
        password2 = request.form.get("password2", "")
        if password != password2:
            flash("Las contraseñas no coinciden.", "error")
        elif not password:
            flash("La contraseña no puede estar vacía.", "error")
        else:
            user.set_password(password)
            db.session.commit()
            flash("Contraseña actualizada correctamente.", "success")
            return redirect(url_for("admin.list_users"))

    return render_template("reset_password.html", title="Resetear contraseña", user=user)


# ---------------- Aprobadores -------------
@admin_bp.route("/approvers", methods=["GET", "POST"])
@login_required
@admin_required
def manage_approvers():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("El nombre no puede estar vacío.", "error")
        elif Approver.query.filter_by(name=name).first():
            flash("Ya existe un aprobador con ese nombre.", "error")
        else:
            ap = Approver(name=name, active=True)
            db.session.add(ap)
            db.session.commit()
            flash("Aprobador agregado correctamente.", "success")
            return redirect(url_for("admin.manage_approvers"))

    approvers = Approver.query.order_by(Approver.name.asc()).all()
    return render_template("approvers.html", title="Aprobadores", approvers=approvers)


@admin_bp.route("/approvers/<int:approver_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle_approver(approver_id):
    ap = db.session.get(Approver, approver_id)
    if not ap:
        return "No encontrado", 404
    ap.active = not ap.active
    db.session.commit()
    return redirect(url_for("admin.manage_approvers"))


@admin_bp.route("/approvers/<int:approver_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_approver(approver_id):
    ap = db.session.get(Approver, approver_id)
    if not ap:
        return "No encontrado", 404
    for e in OvertimeEntry.query.filter_by(approved_by_id=ap.id).all():
        e.approved_by_id = None
    db.session.delete(ap)
    db.session.commit()
    flash("Aprobador eliminado y referencias limpiadas.", "info")
    return redirect(url_for("admin.manage_approvers"))


# ---------------- Productos ---------------
@admin_bp.route("/products", methods=["GET", "POST"])
@login_required
@admin_required
def manage_products():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("El nombre no puede estar vacío.", "error")
        elif Product.query.filter_by(name=name).first():
            flash("Ya existe un producto con ese nombre.", "error")
        else:
            p = Product(name=name, active=True)
            db.session.add(p)
            db.session.commit()
            flash("Producto agregado correctamente.", "success")
            return redirect(url_for("admin.manage_products"))

    products = Product.query.order_by(Product.name.asc()).all()
    return render_template("products.html", title="Productos", products=products)


@admin_bp.route("/products/<int:product_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle_product(product_id):
    p = db.session.get(Product, product_id)
    if not p:
        return "No encontrado", 404
    p.active = not p.active
    db.session.commit()
    return redirect(url_for("admin.manage_products"))


@admin_bp.route("/products/<int:product_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_product(product_id):
    p = db.session.get(Product, product_id)
    if not p:
        return "No encontrado", 404
    for e in OvertimeEntry.query.filter_by(product_id=p.id).all():
        e.product_id = None
    db.session.delete(p)
    db.session.commit()
    flash("Producto eliminado y referencias limpiadas.", "info")
    return redirect(url_for("admin.manage_products"))


# ---------------- Actividades -------------
@admin_bp.route("/activities", methods=["GET", "POST"])
@login_required
@admin_required
def manage_activities():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("El nombre no puede estar vacío.", "error")
        elif Activity.query.filter_by(name=name).first():
            flash("Ya existe una actividad con ese nombre.", "error")
        else:
            a = Activity(name=name, active=True)
            db.session.add(a)
            db.session.commit()
            flash("Actividad agregada correctamente.", "success")
            return redirect(url_for("admin.manage_activities"))

    activities = Activity.query.order_by(Activity.name.asc()).all()
    return render_template("activities.html", title="Actividades", activities=activities)


@admin_bp.route("/activities/<int:activity_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle_activity(activity_id):
    a = db.session.get(Activity, activity_id)
    if not a:
        return "No encontrado", 404
    a.active = not a.active
    db.session.commit()
    return redirect(url_for("admin.manage_activities"))


@admin_bp.route("/activities/<int:activity_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_activity(activity_id):
    a = db.session.get(Activity, activity_id)
    if not a:
        return "No encontrado", 404
    for e in OvertimeEntry.query.filter_by(activity_id=a.id).all():
        e.activity_id = None
    db.session.delete(a)
    db.session.commit()
    flash("Actividad eliminada y referencias limpiadas.", "info")
    return redirect(url_for("admin.manage_activities"))


# ---------------- Exportar Excel ----------
@admin_bp.route("/export")
@login_required
@admin_required

def export_overtime_excel():
    user_id = request.args.get("user_id", type=int)
    product_id = request.args.get("product_id", type=int)
    activity_id = request.args.get("activity_id", type=int)
    entry_type = request.args.get("entry_type", "")
    date_from_str = request.args.get("date_from", "")
    date_to_str = request.args.get("date_to", "")

    date_from = parse_date(date_from_str)
    date_to = parse_date(date_to_str)

    query = OvertimeEntry.query.join(User)

    if user_id:
        query = query.filter(OvertimeEntry.user_id == user_id)

    if product_id:
        query = query.filter(OvertimeEntry.product_id == product_id)
    if activity_id:
        query = query.filter(OvertimeEntry.activity_id == activity_id)
    if entry_type:
        query = query.filter(OvertimeEntry.entry_type == entry_type)

    if date_from:
        query = query.filter(OvertimeEntry.date >= date_from)
    if date_to:
        query = query.filter(OvertimeEntry.date <= date_to)

    query = query.filter(OvertimeEntry.is_deleted == False)

    entries = query.order_by(OvertimeEntry.date.desc(), OvertimeEntry.start_time.desc()).all()

    rows = []
    for e in entries:
        rows.append(
            {
                "Usuario": e.user.full_name,
                "Usuario (login)": e.user.username,
                "Fecha": e.date.strftime("%Y-%m-%d"),
                "Hora inicio": e.start_time.strftime("%H:%M"),
                "Hora fin": e.end_time.strftime("%H:%M"),
                "Tipo": e.entry_type,
                "Horas": e.total_hours,
                "Producto": e.product.name if e.product else "",
                "Actividad": e.activity.name if e.activity else "",
                "Aprobado por": e.approver.name if e.approver else "",
                "Observaciones": e.notes or "",
            }
        )

    df = pd.DataFrame(rows)
    output = io.BytesIO()
    if not df.empty:
        df.to_excel(output, index=False)
    else:
        df_empty = pd.DataFrame(
            columns=[
                "Usuario",
                "Usuario (login)",
                "Fecha",
                "Hora inicio",
                "Hora fin",
                "Tipo",
                "Horas",
                "Producto",
                "Actividad",
                "Aprobado por",
                "Observaciones",
            ]
        )
        df_empty.to_excel(output, index=False)

    output.seek(0)
    filename = f"reporte_horas_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )

@admin_bp.route("/overtime/new", methods=["GET", "POST"])
@login_required
@admin_required
def new_overtime_for_user():
    users = User.query.order_by(User.full_name.asc()).all()
    approvers = Approver.query.filter_by(active=True).order_by(Approver.name.asc()).all()
    products = Product.query.filter_by(active=True).order_by(Product.name.asc()).all()
    activities = Activity.query.filter_by(active=True).order_by(Activity.name.asc()).all()

    if request.method == "POST":
        user_id = request.form.get("user_id")
        date_str = request.form.get("date")
        start_time_str = request.form.get("start_time")
        end_time_str = request.form.get("end_time")
        entry_type = request.form.get("entry_type", "Horas Extras")
        product_id = request.form.get("product_id")
        activity_id = request.form.get("activity_id")
        approved_by_id = request.form.get("approved_by_id")
        notes = request.form.get("notes", "").strip() or None

        if not user_id:
            flash("Debe seleccionar un usuario.", "error")
        else:
            date_val = parse_date(date_str)
            start_time_val = parse_time(start_time_str)
            end_time_val = parse_time(end_time_str)

            if not date_val or not start_time_val or not end_time_val:
                flash("Fecha y horas deben tener un formato válido.", "error")
            else:
                total_hours = compute_total_hours(start_time_val, end_time_val)
                entry = OvertimeEntry(
                    user_id=int(user_id),
                    date=date_val,
                    start_time=start_time_val,
                    end_time=end_time_val,
                    total_hours=total_hours,
                    entry_type=entry_type,
                    product_id=int(product_id) if product_id else None,
                    activity_id=int(activity_id) if activity_id else None,
                    approved_by_id=int(approved_by_id) if approved_by_id else None,
                    notes=notes,
                )
                db.session.add(entry)
                db.session.commit()
                flash("Registro de horas creado para el usuario seleccionado.", "success")
                return redirect(url_for("admin.dashboard", user_id=user_id))

    return render_template(
        "overtime_form.html",
        title="Registrar Horas (Admin)",
        entry=None,
        approvers=approvers,
        products=products,
        activities=activities,
        edit_mode=False,
        cancel_url=url_for("admin.dashboard"),
        users=users,
    )


@admin_bp.route("/overtime/<int:entry_id>/soft-delete", methods=["POST"])
@login_required
@admin_required
def soft_delete_overtime(entry_id):
    entry = db.session.get(OvertimeEntry, entry_id)
    if not entry:
        return "Registro no encontrado", 404
    entry.is_deleted = True
    db.session.commit()
    flash("Registro marcado como eliminado (recuperable).", "info")
    return redirect(url_for("admin.dashboard", user_id=entry.user_id))


@admin_bp.route("/overtime/<int:entry_id>/restore", methods=["POST"])
@login_required
@admin_required
def restore_overtime(entry_id):
    entry = db.session.get(OvertimeEntry, entry_id)
    if not entry:
        return "Registro no encontrado", 404
    entry.is_deleted = False
    db.session.commit()
    flash("Registro restaurado correctamente.", "success")
    return redirect(url_for("admin.dashboard", user_id=entry.user_id))


@admin_bp.route("/overtime/<int:entry_id>/hard-delete", methods=["POST"])
@login_required
@admin_required
def hard_delete_overtime(entry_id):
    entry = db.session.get(OvertimeEntry, entry_id)
    if not entry:
        return "Registro no encontrado", 404
    user_id = entry.user_id
    db.session.delete(entry)
    db.session.commit()
    flash("Registro eliminado definitivamente.", "warning")
    return redirect(url_for("admin.dashboard", user_id=user_id))

