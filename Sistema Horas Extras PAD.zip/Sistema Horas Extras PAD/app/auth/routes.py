from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import current_user, login_user, logout_user, login_required

from app import db
from app.models import User

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    if request.method == "POST":
        username_or_email = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = User.query.filter(
            (User.username == username_or_email) | (User.email == username_or_email)
        ).first()

        if not user or not user.check_password(password):
            flash("Usuario o contraseña incorrectos.", "error")
        else:
            login_user(user)
            flash("Inicio de sesión correcto.", "success")
            next_page = request.args.get("next")
            return redirect(next_page or url_for("main.index"))

    return render_template("login.html", title="Iniciar sesión")


@auth_bp.route("/logout")
def logout():
    logout_user()
    flash("Sesión cerrada correctamente.", "info")
    return redirect(url_for("auth.login"))


@auth_bp.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        new_password2 = request.form.get("new_password2", "")

        if not current_user.check_password(current_password):
            flash("La contraseña actual no es correcta.", "error")
        elif not new_password:
            flash("La nueva contraseña no puede estar vacía.", "error")
        elif new_password != new_password2:
            flash("La nueva contraseña y la confirmación no coinciden.", "error")
        else:
            current_user.set_password(new_password)
            db.session.commit()
            flash("Contraseña actualizada correctamente.", "success")
            return redirect(url_for("main.index"))

    return render_template("change_password.html", title="Cambiar contraseña")
