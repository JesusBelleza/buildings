import os
import sqlite3

from . import db
from .models import User  # Ensure model imported so table exists


def _get_db_path():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    return os.path.join(base_dir, "overtime.db")


def ensure_schema():
    """Asegura que columnas nuevas existan en bases antiguas."""
    db_path = _get_db_path()
    if not os.path.exists(db_path):
        return

    conn = sqlite3.connect(db_path)
    try:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(overtime_entries);")
        columns = [row[1] for row in cur.fetchall()]

        if "entry_type" not in columns:
            cur.execute(
                "ALTER TABLE overtime_entries "
                "ADD COLUMN entry_type VARCHAR(20) NOT NULL DEFAULT 'Horas Extras';"
            )
            conn.commit()
        if "approved_by_id" not in columns:
            cur.execute(
                "ALTER TABLE overtime_entries "
                "ADD COLUMN approved_by_id INTEGER;"
            )
            conn.commit()
        if "product_id" not in columns:
            cur.execute(
                "ALTER TABLE overtime_entries "
                "ADD COLUMN product_id INTEGER;"
            )
            conn.commit()
        if "activity_id" not in columns:
            cur.execute(
                "ALTER TABLE overtime_entries "
                "ADD COLUMN activity_id INTEGER;"
            )
            conn.commit()
        if "is_deleted" not in columns:
            cur.execute(
                "ALTER TABLE overtime_entries "
                "ADD COLUMN is_deleted BOOLEAN NOT NULL DEFAULT 0;"
            )
            conn.commit()
    finally:
        conn.close()


def init_db_and_create_default_admin():
    """Inicializa la BD y crea admin por defecto si no existe."""
    from . import models  # noqa: F401  # para que existan las tablas

    db.create_all()
    ensure_schema()

    admin_exists = User.query.filter_by(role="admin").first()
    if not admin_exists:
        admin = User(
            username="admin",
            full_name="Administrador",
            email="admin@example.com",
            role="admin",
        )
        admin.set_password("admin123")
        db.session.add(admin)
        db.session.commit()
        print(">>> Usuario admin creado: admin / admin123")
