from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from . import db, login_manager


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    full_name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="user")  # 'admin' o 'user'

    overtime_entries = db.relationship("OvertimeEntry", backref="user", lazy=True)

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def is_admin(self) -> bool:
        return self.role == "admin"


class Approver(db.Model):
    __tablename__ = "approvers"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    active = db.Column(db.Boolean, default=True)

    overtime_entries = db.relationship("OvertimeEntry", backref="approver", lazy=True)


class Product(db.Model):
    __tablename__ = "products"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    active = db.Column(db.Boolean, default=True)

    overtime_entries = db.relationship("OvertimeEntry", backref="product", lazy=True)


class Activity(db.Model):
    __tablename__ = "activities"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    active = db.Column(db.Boolean, default=True)

    overtime_entries = db.relationship("OvertimeEntry", backref="activity", lazy=True)


class OvertimeEntry(db.Model):
    __tablename__ = "overtime_entries"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    date = db.Column(db.Date, nullable=False)  # Fecha
    start_time = db.Column(db.Time, nullable=False)  # Hora de inicio
    end_time = db.Column(db.Time, nullable=False)  # Hora de fin
    total_hours = db.Column(db.Float, nullable=False)  # Total horas positivas
    entry_type = db.Column(db.String(20), nullable=False)  # 'Horas Extras' o 'Compensación'

    # Producto y Actividad (listas desplegables)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=True)
    activity_id = db.Column(db.Integer, db.ForeignKey("activities.id"), nullable=True)

    # Campo legado (antes se usaba para motivo / actividad)
    reason = db.Column(db.String(255), nullable=True)

    compensation_date = db.Column(db.Date, nullable=True)  # Campo legado, no usado
    approved_by_id = db.Column(db.Integer, db.ForeignKey("approvers.id"), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    is_deleted = db.Column(db.Boolean, nullable=False, default=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))
