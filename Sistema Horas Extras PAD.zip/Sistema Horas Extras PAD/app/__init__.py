from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message_category = "info"


def create_app(config_class=None):
    """
    Fábrica de aplicación Flask.
    """
    from config import Config

    app = Flask(__name__, instance_relative_config=False)

    # Cargar configuración
    if config_class is None:
        app.config.from_object(Config)
    else:
        app.config.from_object(config_class)

    # Inicializar extensiones
    db.init_app(app)
    login_manager.init_app(app)

    # Importar modelos para que SQLAlchemy conozca las tablas
    from . import models  # noqa: F401

    # Registrar blueprints
    from .auth.routes import auth_bp
    from .main.routes import main_bp
    from .admin.routes import admin_bp
    from .overtime.routes import overtime_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(overtime_bp, url_prefix="/overtime")

    # Importar aquí para evitar import circular con db
    from .config_helpers import init_db_and_create_default_admin

    # Inicializar BD y crear admin por defecto
    with app.app_context():
        init_db_and_create_default_admin()

    return app
