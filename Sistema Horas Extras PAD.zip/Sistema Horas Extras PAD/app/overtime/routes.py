from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app import db
from app.models import OvertimeEntry, Approver, Product, Activity
from app.utils import parse_date, parse_time, compute_total_hours

overtime_bp = Blueprint("overtime", __name__)


@overtime_bp.route("/mine")
@login_required
def my_overtime():
    entries = (
        OvertimeEntry.query.filter_by(user_id=current_user.id)
        .filter(OvertimeEntry.is_deleted == False)
        .order_by(OvertimeEntry.date.desc(), OvertimeEntry.start_time.desc())
        .all()
    )
    total_extra = sum(e.total_hours for e in entries if e.entry_type == "Horas Extras") if entries else 0.0
    total_comp = sum(e.total_hours for e in entries if e.entry_type == "Compensación") if entries else 0.0
    net_hours = total_extra - total_comp
    return render_template(
        "my_overtime.html",
        title="Mis Horas",
        entries=entries,
        total_extra=total_extra,
        total_comp=total_comp,
        net_hours=net_hours,
    )


@overtime_bp.route("/new", methods=["GET", "POST"])
@login_required
def new_overtime():
    approvers = Approver.query.filter_by(active=True).order_by(Approver.name.asc()).all()
    products = Product.query.filter_by(active=True).order_by(Product.name.asc()).all()
    activities = Activity.query.filter_by(active=True).order_by(Activity.name.asc()).all()

    if request.method == "POST":
        date_str = request.form.get("date")
        start_time_str = request.form.get("start_time")
        end_time_str = request.form.get("end_time")
        entry_type = request.form.get("entry_type", "Horas Extras")
        product_id = request.form.get("product_id")
        activity_id = request.form.get("activity_id")
        approved_by_id = request.form.get("approved_by_id")
        notes = request.form.get("notes", "").strip() or None

        date_val = parse_date(date_str)
        start_time_val = parse_time(start_time_str)
        end_time_val = parse_time(end_time_str)

        if not date_val or not start_time_val or not end_time_val:
            flash("Fecha y horas deben tener un formato válido.", "error")
        else:
            total_hours = compute_total_hours(start_time_val, end_time_val)
            entry = OvertimeEntry(
                user_id=current_user.id,
                date=date_val,
                start_time=start_time_val,
                end_time=end_time_val,
                total_hours=total_hours,
                entry_type=entry_type,
                product_id=int(product_id) if product_id else None,
                activity_id=int(activity_id) if activity_id else None,
                approved_by_id=int(approved_by_id) if approved_by_id else None,
                notes=notes,
            )
            db.session.add(entry)
            db.session.commit()
            flash("Registro de horas guardado correctamente.", "success")
            return redirect(url_for("overtime.my_overtime"))

    return render_template(
        "overtime_form.html",
        title="Registrar Horas",
        entry=None,
        approvers=approvers,
        products=products,
        activities=activities,
        edit_mode=False,
        cancel_url=url_for("overtime.my_overtime"),
    )


@overtime_bp.route("/<int:entry_id>/edit", methods=["GET", "POST"])
@login_required
def edit_overtime(entry_id):
    # Solo administrador puede editar registros
    if not current_user.is_admin():
        return "No autorizado", 403

    entry = db.session.get(OvertimeEntry, entry_id)
    if not entry:
        return "Registro no encontrado", 404

    approvers = Approver.query.filter_by(active=True).order_by(Approver.name.asc()).all()
    products = Product.query.filter_by(active=True).order_by(Product.name.asc()).all()
    activities = Activity.query.filter_by(active=True).order_by(Activity.name.asc()).all()

    if request.method == "POST":
        date_str = request.form.get("date")
        start_time_str = request.form.get("start_time")
        end_time_str = request.form.get("end_time")
        entry_type = request.form.get("entry_type", "Horas Extras")
        product_id = request.form.get("product_id")
        activity_id = request.form.get("activity_id")
        approved_by_id = request.form.get("approved_by_id")
        notes = request.form.get("notes", "").strip() or None

        date_val = parse_date(date_str)
        start_time_val = parse_time(start_time_str)
        end_time_val = parse_time(end_time_str)

        if not date_val or not start_time_val or not end_time_val:
            flash("Fecha y horas deben tener un formato válido.", "error")
        else:
            total_hours = compute_total_hours(start_time_val, end_time_val)
            entry.date = date_val
            entry.start_time = start_time_val
            entry.end_time = end_time_val
            entry.total_hours = total_hours
            entry.entry_type = entry_type
            entry.product_id = int(product_id) if product_id else None
            entry.activity_id = int(activity_id) if activity_id else None
            entry.approved_by_id = int(approved_by_id) if approved_by_id else None
            entry.notes = notes
            db.session.commit()
            flash("Registro actualizado correctamente.", "success")
            return redirect(url_for("admin.dashboard"))

    return render_template(
        "overtime_form.html",
        title="Editar registro",
        entry=entry,
        approvers=approvers,
        products=products,
        activities=activities,
        edit_mode=True,
        cancel_url=url_for("admin.dashboard"),
    )

@overtime_bp.route("/export")
@login_required
def export_my_overtime():
    from flask import send_file
    from io import BytesIO
    import pandas as pd

    entries = (
        OvertimeEntry.query.filter_by(user_id=current_user.id)
        .filter(OvertimeEntry.is_deleted == False)
        .order_by(OvertimeEntry.date.desc(), OvertimeEntry.start_time.desc())
        .all()
    )

    data = []
    for e in entries:
        data.append({
            "Fecha": e.date.strftime('%Y-%m-%d'),
            "Inicio": e.start_time.strftime('%H:%M'),
            "Fin": e.end_time.strftime('%H:%M'),
            "Tipo": e.entry_type,
            "Horas": e.total_hours,
            "Producto": e.product.name if e.product else "",
            "Actividad": e.activity.name if e.activity else "",
            "Aprobado por": e.approver.name if e.approver else "",
            "Observaciones": e.notes or ""
        })

    df = pd.DataFrame(data)

    total_extra = sum(e.total_hours for e in entries if e.entry_type == "Horas Extras")
    total_comp = sum(e.total_hours for e in entries if e.entry_type == "Compensación")
    net = total_extra - total_comp

    summary = pd.DataFrame([
        ["Total Horas Extras", total_extra],
        ["Total Compensación", total_comp],
        ["Horas Acumuladas", net]
    ], columns=["Métrica", "Valor"])

    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Registros")
        summary.to_excel(writer, index=False, sheet_name="Consolidado")

    output.seek(0)
    filename = f"horas_usuario_{current_user.username}.xlsx"
    return send_file(output, as_attachment=True, download_name=filename,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

