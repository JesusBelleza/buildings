from datetime import datetime, date, time
from functools import wraps

from flask import abort
from flask_login import current_user


def parse_date(value: str):
    if not value:
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        return None


def parse_time(value: str):
    if not value:
        return None
    try:
        return datetime.strptime(value, "%H:%M").time()
    except ValueError:
        return None


def compute_total_hours(start: time, end: time) -> float:
    """Calcula horas totales entre dos tiempos (en horas decimales, siempre positivo)."""
    if not start or not end:
        return 0.0
    start_dt = datetime.combine(date.today(), start)
    end_dt = datetime.combine(date.today(), end)
    if end_dt < start_dt:
        # Si la hora fin es menor, asumimos que pasa al día siguiente
        end_dt = end_dt.replace(day=end_dt.day + 1)
    delta = end_dt - start_dt
    return round(delta.total_seconds() / 3600.0, 2)


def admin_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not getattr(current_user, "is_admin", lambda: False)():
            abort(403)
        return func(*args, **kwargs)

    return wrapper
